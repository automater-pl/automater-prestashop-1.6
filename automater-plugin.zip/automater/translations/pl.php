<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{automater}prestashop>automater_7444a336adb46b735e24a0942ef29a0c'] = 'Automater.pl';
$_MODULE['<{automater}prestashop>automater_46c4e82d7a696369faf9509c36f96d6b'] = 'Moduł do integracji z Automater.pl';
$_MODULE['<{automater}prestashop>automater_f38f5974cdc23279ffe6d203641a8bdf'] = 'Ustawienia zaktualizowane.';
$_MODULE['<{automater}prestashop>automater_ca15313336e618d52b5e3873dfb34999'] = 'Brak dostępu: sprawdź poprawność API Key i API secret.';
$_MODULE['<{automater}prestashop>automater_f4f70727dc34561dfde1a3c529b6205c'] = 'Ustawienia';
$_MODULE['<{automater}prestashop>automater_ec53a8c4f07baed5d8825072c89799be'] = 'Status';
$_MODULE['<{automater}prestashop>automater_b9f5c797ebbf55adccdd8539a65a0241'] = 'Nieaktywny';
$_MODULE['<{automater}prestashop>automater_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktywny';
$_MODULE['<{automater}prestashop>automater_381f673bbc9cf3f135f7510754086829'] = 'Jeśli API jest aktywne to transakcje będą przesyłane do systemu Automater.';
$_MODULE['<{automater}prestashop>automater_d876ff8da67c3731ae25d8335a4168b4'] = 'API Key';
$_MODULE['<{automater}prestashop>automater_71bbaea14dbff6f6f3bc29434de73d73'] = 'Możesz pobrać tą wartość w panelu użytkownika w zakładce Ustawienia / API.';
$_MODULE['<{automater}prestashop>automater_1ddec0f92f297e937bdf409977df0c02'] = 'API Secret';
$_MODULE['<{automater}prestashop>automater_266fa888c1276cad22b2212dd62471af'] = 'Status transakcji';
$_MODULE['<{automater}prestashop>automater_318ad291f30689714c1c2d67534547f5'] = 'Jeśli ta opcja jest aktywna to Klient otrzyma wiadomość ze statusem transakcji z Automater. ';
$_MODULE['<{automater}prestashop>automater_c9cc8cce247e49bae79f15173ce97354'] = 'Zapisz';
$_MODULE['<{automater}prestashop>automater_630f6dc397fe74e52d5189e2c80f282b'] = 'Powrót do listy';
$_MODULE['<{automater}prestashop>display_admin_products_extra_7d50c0d8203053f63e854f99035857c9'] = 'Powiąż produkt ze sklepu z Automater';
$_MODULE['<{automater}prestashop>display_admin_products_extra_9f145d1f3b934a83e9e2d8e38e0e8b4a'] = 'Wybierz powiązany produkt z Automater';
$_MODULE['<{automater}prestashop>display_admin_products_extra_fe5bebb7828cbe02fc1b48adb0d784a9'] = '--- wybierz produkt ---';
